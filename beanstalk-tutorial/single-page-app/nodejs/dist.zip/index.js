"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const fs_1 = __importDefault(require("fs"));
const html = fs_1.default.readFileSync('index.html');
const port = process.env.PORT || 3000;
const log = function (entry) {
    fs_1.default.appendFileSync('/tmp/sample-app.log', new Date().toISOString() + ' - ' + entry + '\n');
};
const server = http_1.default.createServer(function (req, res) {
    if (req.method === 'POST') {
        let body = '';
        req.on('data', function (chunk) {
            body += chunk;
        });
        req.on('end', function () {
            if (req.url === '/') {
                log('Received message: ' + body);
            }
            else if (req.url === '/scheduled') {
                log('Received task ' +
                    req.headers['x-aws-sqsd-taskname'] +
                    ' scheduled at ' +
                    req.headers['x-aws-sqsd-scheduled-at']);
            }
            res.writeHead(200, 'OK', { 'Content-Type': 'text/plain' });
            res.end();
        });
    }
    else {
        res.writeHead(200);
        res.write(html);
        res.end();
    }
});
server.listen(port);
console.log('Server running at http://127.0.0.1:' + port + '/');
//# sourceMappingURL=index.js.map